var krms_config ={						
	'ApiUrl':"",    
	'AppTitle':"KARENDERIA",
	'ApiKey' : '',	
	'debug': false
};