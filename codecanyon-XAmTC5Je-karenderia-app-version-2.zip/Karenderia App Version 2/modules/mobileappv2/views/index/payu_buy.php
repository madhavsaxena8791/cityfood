
<div class="content_wrap">
<?php
echo $form;
?>
</div>